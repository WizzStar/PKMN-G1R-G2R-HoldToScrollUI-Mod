# Changelog

Format: [keep a changelog](https://keepachangelog.com/en/1.1.0/).
Version headings match `manifest.json`'s `version`.

## 1.0.4

### Changed

- Display name is now **G1R HoldToScrollUI Mod** (manifest id unchanged: `hold_to_scroll_ui`).

## 1.0.3

### Fixed

- Holding **Right** on HOLD DELAY / REPEAT SPEED no longer runaway-fires. Delay and rate are snapshotted when a hold starts, so Left/Right match Up/Down list scroll timing even while those options change under your thumb.

## 1.0.2

### Added

- Hold **Left** / **Right** also auto-repeats in menus (options rows, value steppers, etc.), with the same delay/speed as Up/Down. Still UI-only.

## 1.0.1

### Changed

- **REPEAT SPEED** is now a **1–5** choice (default **3**), not a raw frame number.
- Speed **3** uses the tuned **10-frame** cadence; 1/2 are slightly slower (14 / 12), 4/5 slightly faster (8 / 6).

## 1.0.0

### Added

- Hold **Up** / **Down** in menus to auto-scroll after a short delay.
- **AUTO SCROLL**, **HOLD DELAY**, and **REPEAT SPEED** mod options.
- `ui.list_menu` enablement so bag / shop / list UIs use engine `keyRepeat`.
- `input.step` synthetic edges so Start menu, party, options, and other-mod screens that read `wasPressed` also repeat.
- Overworld gate: never repeats while `stack:top().isOverworld`.
- Opt-out via `noDpadRepeat` / `dpadRepeat = false`, screen-id denylist, and `mod.exports`.
