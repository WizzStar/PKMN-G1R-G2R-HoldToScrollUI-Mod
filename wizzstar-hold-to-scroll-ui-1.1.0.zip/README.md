# G1R & G2R HoldToScrollUI Mod

Hold any **D-pad** direction in menus to auto-repeat after a short delay — lists, option rows, and value steppers. Supports **Gen1Recomp** (Red, Blue, Yellow) and **Gen2Recomp** (Gold, Silver, Crystal).

## Persona

Small accessibility / QoL input helper for Gen 1 & Gen 2 Recompilation project menus.

## Try it

1. Enable **G1R & G2R HoldToScrollUI Mod** in the mod manager.
2. Open the Start menu, bag, party, PC, options, or any other menu.
3. Hold **Down** / **Up** to scroll lists, or **Left** / **Right** to step option values — after a brief pause it keeps repeating.
4. Walk around in the overworld — hold does **not** auto-walk; only menus repeat.
5. Tweak **HOLD DELAY** and **REPEAT SPEED** under the mod’s options.

## Defaults

| Option | Default | Meaning |
|---|---|---|
| AUTO SCROLL | ON | Master enable |
| HOLD DELAY | 16 | Frames before the first repeat (~267 ms) |
| REPEAT SPEED | **3** | Middle of a 1–5 ladder (see below) |

### REPEAT SPEED ladder

| Setting | Feel | Frames between repeats |
|---|---|---|
| 1 | Slightly slower | 14 |
| 2 | Slightly slower | 12 |
| **3** | **Default** (the tuned feel) | **10** |
| 4 | Slightly faster | 8 |
| 5 | Fastest | 6 |

## How it stays modular for other mods

| Path | Hook | Covers |
|---|---|---|
| Native list hold-scroll | `ui.list_menu` | Bag, shops, PC item lists, Pokédex lists, any mod `ListMenu` |
| Synthetic edges | `input.step` | Start menu, party, options, ChoiceBox, battle cursors, custom mod screens that call `input:wasPressed` |

So a brand-new menu from another mod usually just works if it uses the shared input API — no per-menu registration required.

### Denylisted Screens (Skipped automatically)

Minigames and specific move selection menus are bypassed to preserve intentional inputs:
* Slot Machine & Surfing Minigame
* Unown Puzzle & Card Flip
* Battle move selection screens

### Opt out (for UI authors)

On your screen object, set either:

```lua
state.noDpadRepeat = true
-- or
state.dpadRepeat = false