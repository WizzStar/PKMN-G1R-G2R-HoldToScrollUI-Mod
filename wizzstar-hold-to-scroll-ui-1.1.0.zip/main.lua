local DEFAULT_DELAY = 16
local DEFAULT_SPEED = 3
local SPEED_FRAMES = {
  [1] = 14,
  [2] = 12,
  [3] = 10,
  [4] = 8,
  [5] = 6,
}
local DEFAULT_RATE = SPEED_FRAMES[DEFAULT_SPEED]

local DENY_SCREEN_IDS = {
  SlotMachine = true,
  SurfingMinigame = true,
  BattleMoveSelect = true,
  BattleMoves = true,
  BattleFight = true,
  MoveSelect = true,
  UnownPuzzle = true,
  CardFlip = true,
}

-- Cached runtime state (zero per-frame table lookups)
local cachedEnabled = true
local cachedDelay = DEFAULT_DELAY
local cachedSpeed = DEFAULT_SPEED
local cachedRate = DEFAULT_RATE

local function optNumber(mod, key, fallback, min, max)
  local v = mod.options and mod.options:get(key)
  local num = tonumber(v) or fallback
  num = math.floor(num + 0.5)
  if num < min then num = min end
  if num > max then num = max end
  return num
end

local function refreshOptions(mod)
  if not mod or not mod.options then return end
  local en = mod.options:get("enabled")
  cachedEnabled = (en ~= false and en ~= "false")
  cachedDelay = optNumber(mod, "initial_delay", DEFAULT_DELAY, 5, 60)
  cachedSpeed = optNumber(mod, "repeat_speed", DEFAULT_SPEED, 1, 5)
  cachedRate = SPEED_FRAMES[cachedSpeed] or DEFAULT_RATE
end

local function getStackTop(game)
  if not game then return nil end
  local stack = game.stack or (game.ui and game.ui.stack)
  if stack and type(stack.top) == "function" then
    return stack:top()
  end
  return nil
end

local function isMenuContext(game)
  local top = getStackTop(game)
  if not top then return false end
  if top.isOverworld then return false end
  if top.noDpadRepeat == true then return false end
  if top.dpadRepeat == false then return false end
  if top.isMoveSelect or top.isBattleMoveSelect then return false end
  local id = top.screenId or top.id
  if id and DENY_SCREEN_IDS[id] then return false end
  return true
end

local function ownsKeyRepeat(top)
  return top and top.keyRepeat == true
end

local function heldDir(input)
  local up = input:isDown("up")
  local down = input:isDown("down")
  if up and not down then return "up" end
  if down and not up then return "down" end
  local left = input:isDown("left")
  local right = input:isDown("right")
  if left and not right then return "left" end
  if right and not left then return "right" end
  return nil
end

local function injectInputPress(input, dir)
  if type(input.press) == "function" then
    input:press(dir)
  elseif type(input.injectPress) == "function" then
    input:injectPress(dir)
  elseif type(input.pressQueue) == "table" then
    input.pressQueue[#input.pressQueue + 1] = dir
  end
end

return function(mod)
  mod.options:define({
    {
      key = "enabled",
      type = "toggle",
      label = "AUTO SCROLL",
      default = true,
    },
    {
      key = "initial_delay",
      type = "number",
      label = "HOLD DELAY",
      default = DEFAULT_DELAY,
      min = 5,
      max = 60,
      step = 1,
    },
    {
      key = "repeat_speed",
      type = "choice",
      label = "REPEAT SPEED",
      default = DEFAULT_SPEED,
      choices = {
        { "1", 1 },
        { "2", 2 },
        { "3", 3 },
        { "4", 4 },
        { "5", 5 },
      },
    },
  })

  refreshOptions(mod)

  mod.exports.isMenuContext = isMenuContext
  mod.exports.denyScreen = function(screenId)
    if type(screenId) == "string" then DENY_SCREEN_IDS[screenId] = true end
  end
  mod.exports.allowScreen = function(screenId)
    if type(screenId) == "string" then DENY_SCREEN_IDS[screenId] = nil end
  end
  mod.exports.defaults = {
    initialDelay = DEFAULT_DELAY,
    repeatSpeed = DEFAULT_SPEED,
    repeatRate = DEFAULT_RATE,
    speedFrames = SPEED_FRAMES,
  }

  mod.hooks:wrap("ui.list_menu", function(next, opts, ctx)
    opts = next(opts, ctx) or opts
    if not cachedEnabled then return opts end
    if opts.noDpadRepeat == true then return opts end
    if opts.dpadRepeat == false then return opts end

    local id = opts.screenId or (ctx and ctx.screenId)
    if id and DENY_SCREEN_IDS[id] then return opts end
    if opts.isMoveSelect or opts.isBattleMoveSelect or (ctx and (ctx.isMoveSelect or ctx.isBattleMoveSelect)) then
      return opts
    end

    opts.keyRepeat = true
    opts.repeatDelay = cachedDelay
    opts.repeatRate = cachedRate
    return opts
  end)

  local holdDirState = nil
  local holdFrames = 0
  local holdDelay = DEFAULT_DELAY
  local holdRate = DEFAULT_RATE

  local function resetHold()
    holdDirState, holdFrames = nil, 0
    holdDelay, holdRate = cachedDelay, cachedRate
  end

  mod.hooks:wrap("input.step", function(nextFn, game, dt)
    -- Fast Exit 1: Master toggle disabled
    if not cachedEnabled then
      if holdDirState then resetHold() end
      return nextFn(game, dt)
    end

    local input = game and game.input
    if not input or type(input.isDown) ~= "function" then
      if holdDirState then resetHold() end
      return nextFn(game, dt)
    end

    -- Fast Exit 2: No D-pad held (skips stack lookups entirely)
    local dir = heldDir(input)
    if not dir then
      if holdDirState then resetHold() end
      return nextFn(game, dt)
    end

    -- Only inspect menu context if a button is actually held down
    if not isMenuContext(game) then
      if holdDirState then resetHold() end
      return nextFn(game, dt)
    end

    local top = getStackTop(game)
    if ownsKeyRepeat(top) then
      if holdDirState then resetHold() end
      return nextFn(game, dt)
    end

    if dir ~= holdDirState then
      holdDirState = dir
      holdFrames = 0
      holdDelay = cachedDelay
      holdRate = cachedRate
    end

    holdFrames = holdFrames + 1
    local afterDelay = holdFrames - holdDelay
    if holdFrames > 1 and afterDelay >= 0 and afterDelay % holdRate == 0 then
      injectInputPress(input, dir)
    end

    return nextFn(game, dt)
  end)

  mod.events:on("mod.options_changed", function(ev)
    if not ev or ev.mod ~= mod.id then return end
    refreshOptions(mod)
  end)

  mod.events:on("save.loaded", function()
    refreshOptions(mod)
  end)

  mod.log:info("hold D-pad in menus to auto-repeat (cached delay=%d rate=%d)",
    cachedDelay, cachedRate)
end