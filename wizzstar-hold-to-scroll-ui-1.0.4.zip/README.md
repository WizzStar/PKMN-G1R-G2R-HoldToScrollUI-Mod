# G1R HoldToScrollUI Mod

Hold any **D-pad** direction in menus to auto-repeat after a short delay — lists, option rows, and value steppers.

## Persona

Small accessibility / QoL input helper for Gen1Recomp menus.

## Try it

1. Enable **G1R HoldToScrollUI Mod** in the mod manager.
2. Open the Start menu, bag, party, PC, options, or any other menu.
3. Hold **Down** / **Up** to scroll lists, or **Left** / **Right** to step option values — after a brief pause it keeps repeating.
4. Walk around in the overworld — hold does **not** auto-walk; only menus repeat.
5. Tweak **HOLD DELAY** and **REPEAT SPEED** under the mod’s options.

## Defaults

| Option | Default | Meaning |
|---|---|---|
| AUTO SCROLL | ON | Master enable |
| HOLD DELAY | 16 | Frames before the first repeat (~267 ms) |
| REPEAT SPEED | **3** | Middle of a 1–5 ladder (see below) |

### REPEAT SPEED ladder

| Setting | Feel | Frames between repeats |
|---|---|---|
| 1 | Slightly slower | 14 |
| 2 | Slightly slower | 12 |
| **3** | **Default** (the tuned feel) | **10** |
| 4 | Slightly faster | 8 |
| 5 | Fastest | 6 |

## How it stays modular for other mods

| Path | Hook | Covers |
|---|---|---|
| Native list hold-scroll | `ui.list_menu` | Bag, shops, PC item lists, Pokédex lists, any mod `ListMenu` |
| Synthetic edges | `input.step` | Start menu, party, options, ChoiceBox, battle cursors, custom mod screens that call `input:wasPressed` |

So a brand-new menu from another mod usually just works if it uses the shared input API — no per-menu registration required.

### Opt out (for UI authors)

On your screen object, set either:

```lua
state.noDpadRepeat = true
-- or
state.dpadRepeat = false
```

Or call the export:

```lua
local api = mod.find("hold_to_scroll_ui")
if api and api.exports then
  api.exports.denyScreen("MyFancyScreen")
end
```

Screens that already set `keyRepeat = true` are skipped by the injector so they do not double-scroll.

## Install

1. Grab `builds/hold-to-scroll-ui/_hold-to-scroll-ui-1.0.4-wizzstar.zip` (or zip this folder)
2. Import through Gen1Recomp’s **MODS** screen
3. Enable **G1R HoldToScrollUI Mod**
