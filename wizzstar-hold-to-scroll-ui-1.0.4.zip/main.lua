-- G1R HoldToScrollUI Mod
--
-- Hold any D-pad direction in menus to repeat after a short delay
-- (Up/Down for list cursors; Left/Right for option rows / value steppers).
-- Never fires on the overworld (walking / field movement).
--
-- Two complementary paths keep this modular for other mods' UI:
--   1. ui.list_menu  — turn on the engine's native ListMenu keyRepeat
--                      (bag, shops, PC lists, dex lists, mod ListMenus).
--   2. input.step    — inject synthetic wasPressed edges for every other
--                      menu that polls game.input:wasPressed (Start menu,
--                      party, options, ChoiceBox, custom mod screens, …).
-- ListMenus that already own keyRepeat are skipped by path 2 so they do
-- not double-fire. Screens may opt out with `noDpadRepeat = true`.

local DEFAULT_DELAY = 16 -- frames (~267 ms at 60 Hz) — matches ListMenu

-- REPEAT SPEED is a 1–5 player-facing ladder. 3 is the middle default and
-- maps to the 10-frame cadence that feels right in-game; each step is only
-- ±2 frames so 1/2 are slightly slower and 4/5 slightly faster.
local DEFAULT_SPEED = 3
local SPEED_FRAMES = {
  [1] = 14, -- slowest
  [2] = 12,
  [3] = 10, -- default
  [4] = 8,
  [5] = 6,  -- fastest
}
local DEFAULT_RATE = SPEED_FRAMES[DEFAULT_SPEED]

-- Minigames / special UIs where hold-repeat feels wrong.
local DENY_SCREEN_IDS = {
  SlotMachine = true,
  SurfingMinigame = true,
}

local function optNumber(mod, key, fallback, min, max)
  local v = mod.options:get(key)
  if type(v) ~= "number" then v = fallback end
  v = math.floor(v + 0.5)
  if v < min then v = min end
  if v > max then v = max end
  return v
end

local function delayFrames(mod)
  return optNumber(mod, "initial_delay", DEFAULT_DELAY, 5, 60)
end

local function speedLevel(mod)
  local v = mod.options:get("repeat_speed")
  if type(v) ~= "number" then v = DEFAULT_SPEED end
  v = math.floor(v + 0.5)
  if v < 1 then v = 1 end
  if v > 5 then v = 5 end
  return v
end

local function rateFrames(mod)
  return SPEED_FRAMES[speedLevel(mod)] or DEFAULT_RATE
end

local function enabled(mod)
  return mod.options:get("enabled") ~= false
end

-- True when the live stack top is a menu/UI we should help scroll.
local function isMenuContext(game)
  if not game or not game.stack or not game.stack.top then return false end
  local top = game.stack:top()
  if not top then return false end
  if top.isOverworld then return false end
  if top.noDpadRepeat == true then return false end
  if top.dpadRepeat == false then return false end
  local id = top.screenId
  if id and DENY_SCREEN_IDS[id] then return false end
  return true
end

-- ListMenu (and any screen that opted into the same fields) already
-- advances its own cursor while a direction is held.
local function ownsKeyRepeat(top)
  return top and top.keyRepeat == true
end

-- One direction at a time. Vertical wins over horizontal so a diagonal
-- stick flick still scrolls the list instead of stomping an option row.
local function heldDir(input)
  local up = input:isDown("up")
  local down = input:isDown("down")
  if up and not down then return "up" end
  if down and not up then return "down" end
  local left = input:isDown("left")
  local right = input:isDown("right")
  if left and not right then return "left" end
  if right and not left then return "right" end
  return nil
end

return function(mod)
  mod.options:define({
    {
      key = "enabled",
      type = "toggle",
      label = "AUTO SCROLL",
      default = true,
    },
    {
      key = "initial_delay",
      type = "number",
      label = "HOLD DELAY",
      default = DEFAULT_DELAY,
      min = 5,
      max = 60,
      step = 1,
    },
    {
      key = "repeat_speed",
      type = "choice",
      label = "REPEAT SPEED",
      default = DEFAULT_SPEED,
      choices = {
        { "1", 1 },
        { "2", 2 },
        { "3", 3 },
        { "4", 4 },
        { "5", 5 },
      },
    },
  })

  -- Inter-mod API: other UI mods can ask whether we would act, or opt a
  -- screen out without forking this mod.
  mod.exports.isMenuContext = isMenuContext
  mod.exports.denyScreen = function(screenId)
    if type(screenId) == "string" then DENY_SCREEN_IDS[screenId] = true end
  end
  mod.exports.allowScreen = function(screenId)
    if type(screenId) == "string" then DENY_SCREEN_IDS[screenId] = nil end
  end
  mod.exports.defaults = {
    initialDelay = DEFAULT_DELAY,
    repeatSpeed = DEFAULT_SPEED,
    repeatRate = DEFAULT_RATE,
    speedFrames = SPEED_FRAMES,
  }

  -- Path 1: every ListMenu (vanilla bag + other mods' lists) gets native
  -- hold-scroll with the player's timing.
  mod.hooks:wrap("ui.list_menu", function(next, opts, ctx)
    opts = next(opts, ctx) or opts
    if not enabled(mod) then return opts end
    if opts.noDpadRepeat == true then return opts end
    opts.keyRepeat = true
    opts.repeatDelay = delayFrames(mod)
    opts.repeatRate = rateFrames(mod)
    return opts
  end)

  -- Path 2: synthetic edges for edge-only menus / custom mod UIs.
  -- Timing is snapshotted when a hold begins. Reading delay/rate live every
  -- frame made HOLD DELAY / REPEAT SPEED runaway: holding Right raised the
  -- delay each step, so afterDelay hit 0 on every following frame and Right
  -- felt much faster than Left (and faster than Up/Down list scroll).
  local holdDir = nil
  local holdFrames = 0
  local holdDelay = DEFAULT_DELAY
  local holdRate = DEFAULT_RATE

  local function resetHold()
    holdDir, holdFrames = nil, 0
    holdDelay, holdRate = DEFAULT_DELAY, DEFAULT_RATE
  end

  mod.hooks:wrap("input.step", function(nextFn, game, dt)
    if not enabled(mod) then
      resetHold()
      return nextFn(game, dt)
    end

    local input = game and game.input
    if not input or type(input.isDown) ~= "function" then
      resetHold()
      return nextFn(game, dt)
    end

    if not isMenuContext(game) then
      resetHold()
      return nextFn(game, dt)
    end

    local top = game.stack:top()
    -- Avoid double-firing alongside ListMenu's own keyRepeat clock.
    if ownsKeyRepeat(top) then
      resetHold()
      return nextFn(game, dt)
    end

    local dir = heldDir(input)
    if dir ~= holdDir then
      -- Match ListMenu: reset on edge/release, then count this frame.
      -- The real press is already queued for this tick — only inject on
      -- later hold frames once HOLD DELAY elapses.
      holdDir = dir
      holdFrames = 0
      if dir then
        holdDelay = delayFrames(mod)
        holdRate = rateFrames(mod)
      end
    end

    if not dir then
      return nextFn(game, dt)
    end

    holdFrames = holdFrames + 1
    local afterDelay = holdFrames - holdDelay
    -- Skip the press frame itself (holdFrames == 1): wasPressed is already
    -- true from the physical edge. First repeat lands at holdFrames == delay.
    if holdFrames > 1 and afterDelay >= 0 and afterDelay % holdRate == 0 then
      local queue = input.pressQueue
      if type(queue) == "table" then
        queue[#queue + 1] = dir
      end
    end

    return nextFn(game, dt)
  end)

  mod.events:on("mod.options_changed", function(ev)
    if not ev or ev.mod ~= mod.id then return end
    -- New values apply on the next hold; the current hold keeps its snapshot.
    mod.log:info("options: enabled=%s delay=%d speed=%d rate=%d",
      tostring(enabled(mod)), delayFrames(mod), speedLevel(mod), rateFrames(mod))
  end)

  mod.log:info("hold D-pad in menus to auto-repeat (delay=%d speed=%d→%df)",
    DEFAULT_DELAY, DEFAULT_SPEED, DEFAULT_RATE)
end
